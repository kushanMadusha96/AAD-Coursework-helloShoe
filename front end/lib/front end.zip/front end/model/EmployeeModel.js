export class EmployeeModel {
    constructor(employeeCode, employeeName, profilePic, gender, status, designation, accessRole, dob, dateOfJoin, address1, address2, address3, address4, address5, contact, email, guardianName, guardianContact) {
            this.employeeCode = employeeCode,
            this.employeeName = employeeName,
            this.profilePic = profilePic,
            this.gender = gender,
            this.status = status,
            this.designation = designation,
            this.accessRole = accessRole,
            this.dob = dob,
            this.dateOfJoin = dateOfJoin,
            this.address1 = address1,
            this.address2 = address2,
            this.address3 = address3,
            this.address4 = address4,
            this.address5 = address5,
            this.contact = contact,
            this.email = email,
            this.guardianName = guardianName,
            this.guardianContact = guardianContact
    }
}