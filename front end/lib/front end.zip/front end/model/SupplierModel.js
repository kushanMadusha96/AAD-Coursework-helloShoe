export class SupplierModel {
    constructor(supplierCode, supplierName, category, address1, address2, address3, address4, address5, address6, contact1, contact2, email) {
        this.supplierCode  = supplierCode;
        this.supplierName = supplierName;
        this.category = category;
        this.address1 = address1;
        this.address2 = address2;
        this.address3 = address3;
        this.address4 = address4;
        this.address5 = address5;
        this.address6 = address6;
        this.contact1 = contact1;
        this.contact2 = contact2;
        this.email = email;
    }
}